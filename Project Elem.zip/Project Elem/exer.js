$(document).ready(function(){
    $("#but-1").on('click', function(){
        $("#box-1").toggle();
    })
    $("#but-2").on('click', function(){
        $("#box-2").toggle();
    })
    $("#but-3").on('click', function(){
        $("#box-3").toggle();
    })
    $("#but-1x").on('click', function(){
        $("#box-4").toggle();
    })
    $("#but-2x").on('click',function(){
        $("#box-5").toggle();
    })
    $("#but-3x").on('click', function(){
        $("#box-6").toggle();
    })
    $("#but-1y").on('click', function(){
        $("#box-7").toggle();
    })
    $("#but-2y").on('click', function(){
        $("#box-8").toggle();
    })
    $("#but-3y").on('click', function(){
        $("#box-9").toggle();
    })

})


